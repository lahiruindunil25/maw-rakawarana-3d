module.exports = {
  content: ["./app/src/main/assets/index.html"],
  theme: {
    extend: {
      colors: {
        glass: {
          bg: "rgba(255, 255, 255, 0.45)",
          border: "rgba(255, 255, 255, 0.6)",
          card: "rgba(255, 255, 255, 0.7)"
        }
      },
      fontFamily: {
        sinhala: ["Noto Sans Sinhala", "sans-serif"],
        poppins: ["Poppins", "sans-serif"]
      }
    }
  },
  safelist: [
    { pattern: /(bg|text|border)-(pink|purple|teal|indigo|green|yellow|red|blue)-(50|100|200|300|400|500|600|700|800|900)/ },
    "hidden", "block", "flex", "grid", "scale-105", "rotate-3", "rotate-6"
  ]
};
