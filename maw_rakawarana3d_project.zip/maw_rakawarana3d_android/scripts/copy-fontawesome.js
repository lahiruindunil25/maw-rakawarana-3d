const fs = require('fs');
const path = require('path');
const src = path.join(__dirname, '..', 'node_modules', '@fortawesome', 'fontawesome-free');
const dst = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'vendor');
fs.mkdirSync(dst, { recursive: true });
fs.copyFileSync(path.join(src, 'css', 'all.min.css'), path.join(dst, 'all.min.css'));
fs.cpSync(path.join(src, 'webfonts'), path.join(dst, 'webfonts'), { recursive: true });
