# මව් රැකවරණ 3D — Android APK Project

මෙම project එක iPhone Safari හරහා GitHub වෙත upload කර GitHub Actions භාවිතයෙන් APK එක build කිරීමට සකස් කර ඇත.

## Offline සූදානම
- Tailwind CSS build වෙලාවේ compile කර app එක තුළට ඇතුළත් කරයි.
- Font Awesome CSS සහ webfonts build වෙලාවේ app assets වෙත copy කරයි.
- Google Fonts CDN ඉවත් කර ඇත; Android හි Sinhala system font fallback භාවිතා වේ.
- App එක WebView තුළ local `file:///android_asset/index.html` වෙතින් ධාවනය වේ.
- Internet permission එකක් ලබා දී නැත; runtime එකේ internet අවශ්‍ය නොවේ.
- LMP/BMI දත්ත localStorage තුළ උපාංගයේම රැඳේ.

## iPhone එකෙන් APK build කරන පියවර
1. GitHub account එකක් තිබේ නම් Safari තුළ github.com වෙත පිවිසෙන්න.
2. New repository එකක් සාදන්න. උදා: `maw-rakawarana-3d`.
3. මෙම ZIP එක unzip කර එහි ඇති සියලුම files/folders repository එකට upload කරන්න. `.github` folder එකත් අනිවාර්යයෙන් upload කරන්න.
4. Repository එකේ **Actions** tab එකට යන්න.
5. **Build offline Android APK** workflow එක තෝරන්න.
6. **Run workflow** ඔබන්න.
7. Build එක සාර්ථක වූ පසු workflow run එකේ **Artifacts** යටතේ `Maw-Rakawarana-3D-APK` බාගන්න.
8. ZIP එක තුළ ඇති `app-debug.apk` Android දුරකථනයකට යවා install කරන්න. Android එකේ “Install unknown apps” අවසරය අවශ්‍ය විය හැක.

## වැදගත් සටහන්
- APK එක build කිරීමට GitHub වෙත අන්තර්ජාල සම්බන්ධතාව අවශ්‍යයි. APK install කර භාවිතා කිරීම සඳහා අන්තර්ජාලය අවශ්‍ය නොවේ.
- මෙය debug APK එකකි; පුද්ගලිකව share/test කිරීම සඳහා සුදුසුය. Play Store release සඳහා වෙනම signing අවශ්‍ය වේ.
- වෛද්‍ය තොරතුරු භාවිතයට පෙර සුදුසු වෛද්‍ය/ප්‍රසව විශේෂඥයෙකුගෙන් සමාලෝචනය කරගන්න. EDD අනුමානයක් පමණි; BMI/බර වැඩිවීමේ අගයන් සියලුම ගර්භණී තත්ත්වයන්ට එකසේ අදාළ නොවේ.
